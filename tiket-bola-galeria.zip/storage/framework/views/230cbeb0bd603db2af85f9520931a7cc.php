<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('libs/datatables/datatables.min.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="col-lg-8">
            <div class="card w-100">
                <div class="card-body">
                    <h5 class="card-title fw-semibold">Trafik Minggu Ini</h5>
                    <div id="chart"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h5 class="card-title mb-3 fw-semibold">Pengunjung Masuk</h5>
                            <h4 class="fw-semibold mb-3"><?php echo e($countDayPengunjungMasuk); ?> Anak</h4>
                            <div class="d-flex align-items-center">
                                <span
                                    class="me-2 rounded-circle bg-light-success round-20 d-flex align-items-center justify-content-center">
                                    <i class="ti ti-arrow-up-left text-success"></i>
                                </span>
                                <p class="fs-3 mb-0"><?php echo e(formatTanggal()); ?></p>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="d-flex justify-content-end">
                                <div
                                    class="text-white bg-success rounded-circle p-6 d-flex align-items-center justify-content-center">
                                    <i class="ti ti-user-check fs-6"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h5 class="card-title mb-3 fw-semibold"> Pengunjung Keluar </h5>
                            <h4 class="fw-semibold mb-3"><?php echo e($countDayPengunjungKeluar); ?> Anak</h4>
                            <div class="d-flex align-items-center">
                                <span
                                    class="me-2 rounded-circle bg-light-danger round-20 d-flex align-items-center justify-content-center">
                                    <i class="ti ti-arrow-down-right text-danger"></i>
                                </span>
                                <p class="fs-3 mb-0"><?php echo e(formatTanggal()); ?></p>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="d-flex justify-content-end">
                                <div
                                    class="text-white bg-danger rounded-circle p-6 d-flex align-items-center justify-content-center">
                                    <i class="ti ti-user-minus fs-6"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title fw-semibold">Pengunjung Masuk</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="pengunjung-masuk-table" class="table table-bordered table-striped" width="100%">
                            <thead>
                                <tr>
                                    <th width="5%">#</th>
                                    <th>Nama Anak</th>
                                    <th>Nama Panggilan</th>
                                    <th>Sisa Waktu</th>
                                    <th>Nama Orang Tua</th>
                                    <th>Tiket</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title fw-semibold">Pengunjung Keluar</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="pengunjung-keluar-table" class="table table-bordered table-striped" width="100%">
                            <thead>
                                <tr>
                                    <th width="5%">#</th>
                                    <th>Nama Anak</th>
                                    <th>Nama Panggilan</th>
                                    <th>Nama Orang Tua</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/datatables/datatables.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            datatableCall('pengunjung-masuk-table', '<?php echo e(route('riwayatPengunjungMasuk')); ?>', [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },
                {
                    data: 'nama_anak',
                    name: 'nama_anak'
                },
                {
                    data: 'nama_panggilan',
                    name: 'nama_panggilan'
                },
                {
                    data: 'durasi',
                    name: 'durasi'
                },
                {
                    data: 'nama_orang_tua',
                    name: 'nama_orang_tua'
                },
                {
                    data: 'tiket',
                    name: 'tiket'
                },
            ]);

            datatableCall('pengunjung-keluar-table', '<?php echo e(route('riwayatPengunjungKeluar')); ?>', [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },
                {
                    data: 'nama_anak',
                    name: 'nama_anak'
                },
                {
                    data: 'nama_panggilan',
                    name: 'nama_panggilan'
                },
                {
                    data: 'nama_orang_tua',
                    name: 'nama_orang_tua'
                },
            ]);

            renderMultipleChart(<?php echo json_encode($dataMasuk); ?>, <?php echo json_encode($dataKeluar); ?>, <?php echo json_encode($labels); ?>);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tiket-bola-galeria\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>