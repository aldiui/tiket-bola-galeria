<?php $__env->startSection('title', 'Ubah Tarif'); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="card">
        <div class="card-header">
            <h5 class="card-title fw-semibold"><?php echo $__env->yieldContent('title'); ?></h5>
        </div>
        <div class="card-body">
            <form id="updateData" autocomplete="off">
                <div class="form-group mb-3">
                    <label for="tarif" class="form-label">Tarif Per Jam <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" name="tarif" id="tarif"
                        placeholder="Masukkan jumlah tarif per jam" value="<?php echo e($pengaturan->tarif ?? ''); ?>">
                    <small class="invalid-feedback" id="errortarif"></small>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><i class="ti ti-pencil me-1"></i>Ubah Tarif</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $("#updateData").submit(function(e) {
                e.preventDefault();
                Swal.fire({
                    title: "Konfirmasi",
                    text: "Jika Setuju Merubah. Apakah Anda yakin?",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Ya, Ubah Tarif!",
                    cancelButtonText: "Batal"
                }).then((result) => {
                    if (result.isConfirmed) {
                        setButtonLoadingState("#updateData .btn.btn-primary", true, 'Ubah Tarif');
                        const url = `<?php echo e(route('ubahTarif')); ?>`;
                        const data = new FormData(this);

                        const successCallback = function(response) {
                            $('#updateData .form-control').removeClass("is-invalid");
                            $('#updateData .invalid-feedback').html("");
                            setButtonLoadingState("#updateData .btn.btn-primary", false,
                                `<i class="ti ti-pencil me-1"></i>Ubah Tarif`);
                            handleSuccess(response, null, null, "no");
                        };

                        const errorCallback = function(error) {
                            setButtonLoadingState("#updateData .btn.btn-primary", false,
                                `<i class="ti ti-pencil me-1"></i>Ubah Tarif`);
                            handleValidationErrors(error, "updateData", ["tarif"]);
                        };

                        ajaxCall(url, "POST", data, successCallback, errorCallback);
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Documents\portofolio\proyek-2024\tiket-bola-galeria\resources\views/admin/pengaturan/ubah-tarif.blade.php ENDPATH**/ ?>