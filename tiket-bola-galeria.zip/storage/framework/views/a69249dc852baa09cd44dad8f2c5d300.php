<?php $__env->startSection('content'); ?>
    <h1>You are currently not connected to any networks.</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Documents\portofolio\proyek-2024\tiket-bola-galeria\resources\views/vendor/laravelpwa/offline.blade.php ENDPATH**/ ?>