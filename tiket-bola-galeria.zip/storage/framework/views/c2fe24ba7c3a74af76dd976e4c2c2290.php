<div class="py-6 px-6 text-center">
    <p class="mb-0 fs-4">Powered by GTR Project</p>
</div>
<?php /**PATH D:\laravel\tiket-bola-galeria\resources\views/components/footer.blade.php ENDPATH**/ ?>