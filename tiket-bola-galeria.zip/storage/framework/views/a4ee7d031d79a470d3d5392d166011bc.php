<?php $__env->startSection('title', 'Laporan Keuangan ' . formatTanggal($tanggalMulai, 'j M Y') . ' - ' . formatTanggal($tanggalSelesai,
    'j M Y')); ?>

    <?php $__env->startPush('style'); ?>
    <?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div>
        <table width="100%" border="1" cellpadding="4" cellspacing="0">
            <thead>
                <tr>
                    <th width="5%">#</th>
                    <th>Nama Anak</th>
                    <th>Durasi</th>
                    <th>Orang Tua</th>
                    <th>Metode Pembayaran</th>
                    <th>Pembayaran</th>
                    <th>Diskon</th>
                    <th>Total</th>
                    <th>Tanggal dan Waktu</th>
                    <th>Admin</th>
                </tr>
            </thead>
            <tbody valign="top">
                <?php $__currentLoopData = $pengunjungMasuks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengunjungMasuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $total = $pengunjungMasuk->durasi_extra
                            ? $pengunjungMasuk->tarif + $pengunjungMasuk->tarif_extra
                            : $pengunjungMasuk->tarif;
                        $totalDenganDiskon = $total - $pengunjungMasuk->diskon ?? 0;
                    ?>
                    <tr>
                        <td align ="center"><?php echo e($loop->iteration); ?></td>
                        <td align="center"><?php echo e($pengunjungMasuk->nama_anak); ?></td>
                        <td align="center">
                            <?php echo e($pengunjungMasuk->durasi_extra ? $pengunjungMasuk->durasi_bermain + $pengunjungMasuk->durasi_extra : $pengunjungMasuk->durasi_bermain); ?>

                            Jam </td>
                        <td align="center"><?php echo e($pengunjungMasuk->nama_orang_tua); ?></td>
                        <td align="center">
                            <?php echo e($pengunjungMasuk->pembayaran_id ? $pengunjungMasuk->pembayaran->nama_bank . ' - ' . $pengunjungMasuk->pembayaran->nama_akun : 'Cash'); ?>

                        </td>
                        <td align="right"><?php echo e(formatRupiah($total)); ?>

                        </td>
                        <td align="right"><?php echo e(formatRupiah($pengunjungMasuk->diskon)); ?></td>
                        <td align="right"><?php echo e(formatRupiah($totalDenganDiskon)); ?></td>
                        <td align="center"><?php echo e(formatTanggal($pengunjungMasuk->created_at, 'j M Y H:i:s')); ?></td>
                        <td align="center"><?php echo e($pengunjungMasuk->user->nama); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5" align="center">Total Pembayaran</td>
                    <td align="right">
                        <?php echo e(formatRupiah($pengunjungMasuks->sum('tarif') + $pengunjungMasuks->sum('tarif_extra'))); ?></td>
                    <td align="right"><?php echo e(formatRupiah($pengunjungMasuks->sum('diskon'))); ?></td>
                    <td align="right">
                        <?php echo e(formatRupiah($pengunjungMasuks->sum('tarif') + $pengunjungMasuks->sum('tarif_extra') - $pengunjungMasuks->sum('diskon'))); ?>

                    </td>
                    <td></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tiket-bola-galeria\resources\views/admin/keuangan/pdf.blade.php ENDPATH**/ ?>