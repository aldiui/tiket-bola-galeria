<?php $__env->startSection('title', 'E-Tiket'); ?>

<?php $__env->startPush('style'); ?>
    <style>
        @keyframes blink {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        .blink {
            animation: blink 1s linear infinite;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div
        class="position-relative overflow-hidden radial-gradient min-vh-100 d-flex align-items-center justify-content-center">
        <div class="d-flex align-items-center justify-content-center w-100">
            <div class="row justify-content-center w-100 py-5">
                <div class="col-md-8 col-lg-5 col-xl-4">
                    <div class="card mb-0 border border-primary border-5">
                        <div class="card-body">
                            <h5 class="fw-semibold text-center mb-3">E-Drop Ticket</h5>
                            <div class="mb-3 text-center">
                                <span class="badge bg-info" id="label-tiket"></span>
                            </div>
                            <input type="hidden" id="now">
                            <div id="detail">
                                <div class="text-center py-5">
                                    <i class="ti ti-reload text-danger me-1"></i>
                                    Belum Ada Tiket
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            getTicketNow()

            setInterval(function() {
                getTicketNow()
            }, 30000);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tiket-bola-galeria\resources\views/admin/tiket/now.blade.php ENDPATH**/ ?>