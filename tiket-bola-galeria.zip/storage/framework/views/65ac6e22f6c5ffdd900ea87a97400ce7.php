<?php $__env->startSection('title', 'Laporan Keuangan ' . $bulanTahun); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div>
        <table width="100%" border="1" cellpadding="2.5" cellspacing="0">
            <thead>
                <tr>
                    <th width="5%">#</th>
                    <th>Nama Anak</th>
                    <th>Durasi</th>
                    <th>Orang Tua</th>
                    <th>Metode Pembayaran</th>
                    <th>Jumlah Pembayaran</th>
                    <th>Tanggal dan Waktu</th>
                    <th>Admin</th>
                </tr>
            </thead>
            <tbody valign="top">
                <?php $__currentLoopData = $pengunjungMasuks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengunjungMasuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align ="center"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($pengunjungMasuk->nama_anak); ?></td>
                        <td><?php echo e($pengunjungMasuk->durasi_bermain); ?> Jam </td>
                        <td><?php echo e($pengunjungMasuk->nama_orang_tua); ?></td>
                        <td><?php echo e($pengunjungMasuk->metode_pembayaran); ?></td>
                        <td><?php echo e(formatRupiah($pengunjungMasuk->tarif)); ?></td>
                        <td><?php echo e(formatTanggal($pengunjungMasuk->created_at, 'j M Y H:i:s')); ?></td>
                        <td><?php echo e($pengunjungMasuk->user->nama); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5" align="center">Total Pembayaran</td>
                    <td><?php echo e(formatRupiah($pengunjungMasuks->sum('tarif'))); ?></td>
                    <td></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Public\Documents\portofolio\proyek-2024\tiket-bola-galeria\resources\views/admin/keuangan/pdf.blade.php ENDPATH**/ ?>