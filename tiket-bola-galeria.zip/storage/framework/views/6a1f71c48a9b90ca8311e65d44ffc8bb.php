<?php $__env->startSection('title', 'E-Tiket'); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('libs/datatables/datatables.min.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
    <div class="min-vh-100"
        style="background-image: url('<?php echo e(asset('images/bali-pagoda-indonesia.jpg')); ?>'); background-size: cover">
        <div class="container">
            <div class="row justify-content-center py-5">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title fw-semibold text-center">Riwayat Pengunjung Masuk <?php echo e(formatTanggal()); ?>

                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="pengunjung-masuk-table" class="table table-bordered table-striped"
                                    width="100%">
                                    <thead>
                                        <tr>
                                            <th width="5%">#</th>
                                            <th>Nama Anak</th>
                                            <th>Sisa Waktu</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('libs/datatables/datatables.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            datatableCall('pengunjung-masuk-table', '<?php echo e(route('eTiket.index')); ?>', [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },
                {
                    data: 'nama_anak',
                    name: 'nama_anak'
                },
                {
                    data: 'durasi',
                    name: 'durasi'
                },
            ]);

            setInterval(function() {
                $("#pengunjung-masuk-table").DataTable().ajax.reload();
            }, 60000);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\tiket-bola-galeria\resources\views/admin/tiket/index.blade.php ENDPATH**/ ?>