<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            line-height: 1.5;
            margin: 0;
            padding: 0;
        }

        h3 {
            margin: 2;
        }
    </style>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
</head>

<body>
    <div align="center">
        <h3><?php echo $__env->yieldContent('title'); ?> </h3>
    </div>
    <hr style="height:1px;background-color:black;">
    <br>
    <?php echo $__env->yieldContent('main'); ?>


    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\Users\Public\Documents\portofolio\proyek-2024\tiket-bola-galeria\resources\views/layouts/pdf.blade.php ENDPATH**/ ?>