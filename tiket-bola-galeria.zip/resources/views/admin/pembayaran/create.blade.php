<div class="modal fade" id="createModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"
    data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel"><span id="label-modal"></span> Data Daftar Bank</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="saveData" autocomplete="off">
                <div class="modal-body">
                    <input type="hidden" id="id">
                    <div class="form-group mb-3">
                        <label for="nama_bank" class="form-label">Nama Akun <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="nama_bank" name="nama_bank">
                        <small class="invalid-feedback" id="errornama_bank"></small>
                    </div>
                    <div class="form-group mb-3">
                        <label for="nama_akun" class="form-label">Nama Akun <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="nama_akun" name="nama_akun">
                        <small class="invalid-feedback" id="errornama_akun"></small>
                    </div>
                    <div class="form-group mb-3">
                        <label for="nomor_rekening" class="form-label">Nomor Rekening <span
                                class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="nomor_rekening" name="nomor_rekening">
                        <small class="invalid-feedback" id="errornomor_rekening"></small>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-plus me-1"></i>Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
